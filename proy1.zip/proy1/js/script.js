document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('formTarea');
    form.addEventListener('submit', () => {
        alert('Tarea enviada correctamente');
    });
});
